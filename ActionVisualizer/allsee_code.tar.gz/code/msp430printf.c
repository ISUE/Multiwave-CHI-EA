/* 
 * msp430printf.c
 *
 * Author: Bryce Kellogg
 * Email:  kellogg@uw.edu
 *
 * Copyright 2013 Bryce Kellogg, UW CSE Wireless Lab
 * All rights reserved.
 *
 * This code is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International
 * License. You should have received a copy of the
 * license with this software.
 *
 * For commercial applications please contact:allsee@cs.washington.edu
 *
 * Provides the fputc and fputs implementations
 * required by printf for the MSP430 line
 * of Texas Instruments uControllers.
 */
#include <stdio.h>
#include <string.h>

#include "msp430printf.h"

// Used by printf
int fputc(int _c, register FILE *_fp) {
	while(TX_BUSY);
	return TX_BUF = (unsigned char) _c;
}

// Used by printf
int fputs(const char *_ptr, register FILE *_fp) {
	unsigned int i, len;
	len = strlen(_ptr);

	for(i = 0; i < len; i++) {
		while(TX_BUSY);
		TX_BUF = (unsigned char) _ptr[i];
	}
	return len;
}
