/*
 * main.c
 *
 * Author: Bryce Kellogg
 * Email:  kellogg@uw.edu
 *
 * Copyright 2013 Bryce Kellogg, UW CSE Wireless Lab
 * All rights reserved.
 *
 *
 * This code is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International
 * License. You should have received a copy of the
 * license with this software.
 *
 * For commercial applications please contact:allsee@cs.washington.edu
 *
 * This is the main program for gesture
 * recognition. It controls the msp430
 * and prints gestures to the UART.
 */

#include <msp430.h> 
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "msp430printf.h"

#define FLICK_MAX_WIDTH 15
#define PUSH_PULL_MAX_WIDTH 100

#define THRESH_DOWN 10
#define THRESH_UP 10
#define GLITCH_THRESH 15
#define POST_THRESH 120

//#define DEBUG_PRINT

typedef enum _gesture {
	NOGESTURE,
	ERROR,
	PUSH,
	PULL,
	FLICK,
	PUSH_PULL,
	PULL_PUSH,
	FLICK_PULL,
	PUSH_FLICK,
	DOUBLE_FLICK
} gesture;

gesture classifySubgesture(uint16_t, uint16_t);
uint16_t avg(uint16_t);
uint16_t getGesture();
void printGesture(uint16_t,uint16_t);

uint16_t val, val_avg, val_dc, val_prev, val_diff;

int main(void) {
    WDTCTL = WDTPW | WDTHOLD;  // Stop watchdog timer

	/*** Configure Clock ***/
    UCSCTL4 |= SELA_1;         // ACLK src = VLOCLK ~= 10 kHz
    // TODO: make CPU clock slower?

    /*** Configure Timer A ***/
    TA0CCR1 = 41;                     // 200 samples/sec  TODO: experiment with less samples.
    TA0CCR0 = TA0CCR1 + 1;
    TA0CCTL1 = OUTMOD_3;              // Set/Reset
    TA0CTL = TASSEL_1 | MC_1 + ID_0;  // ACLK, up to TACCR0, /4

    /*** Configure ADC ***/
    P6DIR &= ~BIT0;
    //P4SEL |= 0;                                        // TODO
    ADC10CTL0 |= ADC10SHT_0 | ADC10ON;                   // Sample-and-hold-time = 4, ADC on
    ADC10CTL1 |= ADC10SHS_1 | ADC10SHP | ADC10CONSEQ_2;  // Sample/hold src = TimerA0, sampling timer, MODOSC, single channel continuous
    ADC10CTL2 |= ADC10RES;                               // 10 bit conversion mode
    ADC10MCTL0 |= ADC10INCH_0;                           // Input channel A0
//    ADC10MCTL0 |= ADC10INCH_1;                           // Input channel A0
    ADC10IE |= ADC10IE0;                                 // enable interrupts
    ADC10CTL0 |= ADC10ENC;                               // Enable Conversion

    /*** Configure UART ***/
	P4SEL |= BIT4 | BIT5;          // P4.4,5 = USCI_A0 TXD/RXD
	UCA1CTL1 |= UCSWRST;           // Put UART in reset
	UCA1CTL1 |= UCSSEL_2;          // SMCLK
	UCA1BR0 = 9;                   // 115200
	UCA1BR1 = 0;                   // 115200
	UCA1MCTL = UCBRS_1 | UCBRF_0;  // Modulation, Oversampling, UCBRSx = 0, UCBRFx = 1
	UCA1CTL1 &= ~UCSWRST;          // Initialize USCI state machine

    P1DIR |= BIT1 + BIT2;

	/*** Initialize Variables ***/
    uint16_t gesture0  = NOGESTURE, gesture1 = NOGESTURE;
	uint8_t i = 0;

//	while(1) {
//		printf("Hello World!\r\n");
//	}

    while(1) {

    	/*** Wait for first gesture ***/
    	while (val_diff < THRESH_UP) {
    		_bis_SR_register(LPM3_bits | GIE);
    	}

    	printf("+ %d\r\n", val_diff);

		gesture0 = getGesture(); // Look at gesture

		/*** Wait for a second gesture ***/
		for (i = 0; i < POST_THRESH; i++) {
			_bis_SR_register(LPM3_bits | GIE);  // Sleep until woken by the ADC
			if (val_diff >= THRESH_UP) {         // Wait until something is happening
				gesture1 = getGesture();
				break;
			}
		}


		printGesture(gesture0, gesture1);
		gesture0 = gesture1 = NOGESTURE;

	}
}

uint16_t getGesture() {
	uint16_t gestureStartIndex = 0, glitchCount = 0, maxIndex = 0, max = 0;
	while(1) {
		_bis_SR_register(LPM3_bits | GIE); // Sleep until woken by the ADC

		// Wait until gesture ends
		if (val_diff >= THRESH_DOWN) {
			gestureStartIndex++;
			glitchCount = 0;
			maxIndex++;
			if (val_dc > max) {
				max = val_dc;
				maxIndex = 0;
			}
			val_diff = 0;
			continue;
		}

		// Make sure end isn't just a glitch
		if (glitchCount++ < GLITCH_THRESH) {
			gestureStartIndex++;
			maxIndex++;
			continue;
		}

		return classifySubgesture(gestureStartIndex - GLITCH_THRESH, maxIndex - GLITCH_THRESH);
	}
}

#define AVG_LEN (64)
#define AVG_MASK (AVG_LEN - 1)
uint16_t avg(uint16_t newVal) {
	static uint16_t avg_buf[AVG_LEN] = {0};
	static uint16_t index = 0;
	static uint32_t sum = 0;  // TODO: change to 16 bits?
	sum -= avg_buf[index & AVG_MASK];
	sum += avg_buf[index++ & AVG_MASK] = newVal;
	return sum / AVG_LEN;    // TODO: Check ASM to make sure it's a shift.
}

gesture classifySubgesture(uint16_t len, uint16_t max) {
//	printf("%d,%d - ", len, max);
	if (len < FLICK_MAX_WIDTH) return FLICK;
	if (len < PUSH_PULL_MAX_WIDTH && max < len/2) return PUSH;
	if (len < PUSH_PULL_MAX_WIDTH && max >= len/2) return PULL;
	return ERROR;
}
void printGesture(uint16_t gesture0, uint16_t gesture1) {
	uint16_t gesture = gesture0;

	P1OUT ^= BIT1;
	printf("-");

	if (gesture0 == FLICK && gesture1 == FLICK) gesture = DOUBLE_FLICK;
	if (gesture0 == FLICK && (gesture1 == PUSH || gesture1 == PULL)) gesture = FLICK_PULL;
	if ((gesture0 == PUSH || gesture0 == PULL) && gesture1 == FLICK) gesture = PUSH_FLICK;
	if (gesture0 == PUSH && gesture1 == PULL) gesture = PUSH_PULL;
	if (gesture0 == PULL && gesture1 == PUSH) gesture = PULL_PUSH;

	switch(gesture) {
		case PUSH:         P1OUT ^= BIT2; printf("PUSH\r\n");         break;
		case PULL:         P1OUT ^= BIT2; printf("PULL\r\n");         break;
		case FLICK:        printf("FLICK\r\n");        break;
		case FLICK_PULL:   printf("ZOOM OUT\r\n");  break;
		case PUSH_FLICK:   printf("ZOOM IN\r\n");  break;
		case PUSH_PULL:    printf("PUNCH\r\n");   break;
		case PULL_PUSH:    printf("REVERSE PUNCH\r\n");   break;
		case DOUBLE_FLICK: printf("DOUBLE FLICK\r\n"); break;
		default: printf("ERROR\r\n");
	}
}

// ADC Interrupt
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void) {
	if (ADC10IV == 12) {
		val = ADC10MEM0;
		val_avg = avg(val);
 		val_dc = abs(val - val_avg);
		val_diff = abs(val - val_prev);
		val_prev = val;
		_bic_SR_register_on_exit(LPM3_bits);
	}
}
