/*
 * uart.h
 *
 * Author: Bryce Kellogg
 * Email:  kellogg@uw.edu
 *
 * Copyright 2013 Bryce Kellogg, UW CSE Wireless Lab
 * All rights reserved.
 *
 * This code is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International
 * License. You should have received a copy of the
 * license with this software.
 *
 * For commercial applications please contact:allsee@cs.washington.edu
 *
 * Header file for an MSP430 implementation
 * of the functions needed by printf.
 */
#ifndef UART_H_
#define UART_H_

#include <msp430.h>
#include <stdio.h>

// TODO: Change based on used microcontroller
// and UART peripheral

// TODO: Calculate Baud rate settings
// TODO: Have intialization function.
#ifdef __MSP430G2553__
#define TX_BUF  UCA0TXBUF
#define TX_BUSY (!(UCA0TXIFG & IFG2))
#endif // __MSP430G2553__

#ifdef __MSP430F5310__
#define TX_BUF  UCA1TXBUF
#define TX_BUSY (!(UCA1IFG & UCTXIFG))
#endif // __MSP430F5310__


void uartInit(void);
int fputc(int _c, register FILE *_fp);
int fputs(const char *_ptr, register FILE *_fp);

#endif /* UART_H_ */
